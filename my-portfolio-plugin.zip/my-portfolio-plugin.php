<?php
/**
 * Plugin Name: My Portfolio Plugin
 * Description: Adds a custom post type for portfolio items and manages categories, tags, and additional details.
 * Version: 1.0.0
 * Author: Ravi Shah
 * Author URI: www.vistavibes.in
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 */

function my_portfolio_post_type() {
    $labels = array(
        'name' => _x('Portfolio Items', 'Post Type General Name', 'textdomain'),
        'singular_name' => _x('Portfolio Item', 'Post Type Singular Name', 'textdomain'),
        'menu_name' => _x('Portfolio', 'Admin Menu Text', 'textdomain'),
        'add_new' => _x('Add New Portfolio Item', 'Portfolio Item', 'textdomain'),
        'add_new_item' => __('Add New Portfolio Item', 'textdomain'),
        'edit_item' => __('Edit Portfolio Item', 'textdomain'),
        'update_item' => __('Update Portfolio Item', 'textdomain'),
        'view_item' => __('View Portfolio Item', 'textdomain'),
        'search_items' => __('Search Portfolio Items', 'textdomain'),
        'not_found' => __('No Portfolio Items found', 'textdomain'),
        'not_found_in_trash' => __('No Portfolio Items found in Trash', 'textdomain'),
        'parent_item_colon' => '',
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-portfolio',
        'supports' => array('title', 'editor', 'thumbnail'),
    );

    register_post_type('portfolio', $args);
}

add_action('init', 'my_portfolio_post_type');

function my_portfolio_categories_taxonomy() {
    $labels = array(
        'name' => _x('Portfolio Categories', 'Taxonomy General Name', 'textdomain'),
        'singular_name' => _x('Portfolio Category', 'Taxonomy Singular Name', 'textdomain'),
        'menu_name' => __('Portfolio Categories'),
        'all_items' => __('All Portfolio Categories'),
    );

    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
        'public' => true,
        'rewrite' => array('slug' => 'portfolio-category'),
        'show_ui' => true,
        'show_in_menu' => true,
        'show_admin_column' => true,
        'query_var' => true,
    );

    register_taxonomy('portfolio_category', array('portfolio'), $args);
}

function my_portfolio_tags_taxonomy() {
    $labels = array(
        'name' => _x('Portfolio Tags', 'Taxonomy General Name', 'textdomain'),
        'singular_name' => _x('Portfolio Tag', 'Taxonomy Singular Name', 'textdomain'),
        'menu_name' => __('Portfolio Tags'),
    );

    $args = array(
        'labels' => $labels,
        'hierarchical' => false,
        'public' => true,
        'rewrite' => array('slug' => 'portfolio-tag'),
        'show_ui' => true,
        'show_in_menu' => true,
        'show_admin_column' => true,
        'query_var' => true,
    );

    register_taxonomy('portfolio_tag', array('portfolio'), $args);
}

add_action('init', 'my_portfolio_categories_taxonomy');
add_action('init', 'my_portfolio_tags_taxonomy');

function my_portfolio_meta_boxes() {
    add_meta_box('portfolio_details', __('Portfolio Details', 'textdomain'), 'my_portfolio_meta_box_content', 'portfolio');
}

function my_portfolio_meta_box_content($post) {
    wp_nonce_field(basename(__FILE__), 'my_portfolio_meta_box_nonce');
    $project_url = get_post_meta($post->ID, 'project_url', true);
    $client_name = get_post_meta($post->ID, 'client_name', true);

    echo '<label for="project_url">';
    _e('Project URL:', 'textdomain');
    echo '</label>';
    echo '<input type="text" name="project_url" id="project_url" value="' . esc_attr($project_url) . '" size="50" />';

    echo '<br>';

    echo '<label for="client_name">';
    _e('Client Name:', 'textdomain');
    echo '</label>';
    echo '<input type="text" name="client_name" id="client_name" value="' . esc_attr($client_name) . '" size="50" />';
}

add_action('add_meta_boxes', 'my_portfolio_meta_boxes');

function my_portfolio_save_meta_boxes($post_id) {
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    if (isset($_POST['my_portfolio_meta_box_nonce']) && wp_verify_nonce($_POST['my_portfolio_meta_box_nonce'], basename(__FILE__))) {
        if (isset($_POST['project_url'])) {
            update_post_meta($post_id, 'project_url', sanitize_text_field($_POST['project_url']));
        }

        if (isset($_POST['client_name'])) {
            update_post_meta($post_id, 'client_name', sanitize_text_field($_POST['client_name']));
        }
    }
}

add_action('save_post', 'my_portfolio_save_meta_boxes');

function my_portfolio_shortcode($atts) {
    $args = shortcode_atts(array(
        'category' => '',
        'tag' => '',
        'columns' => 3,
        'orderby' => 'title',
        'order' => 'asc',
        'count' => -1, // Default: Show all posts. Change this value to the number of posts you want to display.
    ), $atts);

    $query_args = array(
        'post_type' => 'portfolio',
        'posts_per_page' => $args['count'],
        'orderby' => $args['orderby'],
        'order' => $args['order'],
    );

    if (!empty($args['category'])) {
        $query_args['tax_query'] = array(
            array(
                'taxonomy' => 'portfolio_category',
                'field' => 'slug',
                'terms' => array($args['category']),
            )
        );
    }

    if (!empty($args['tag'])) {
        $query_args['tax_query'][] = array(
            'taxonomy' => 'portfolio_tag',
            'field' => 'slug',
            'terms' => array($args['tag']),
        );
    }

    $query = new WP_Query($query_args);

    if ($query->have_posts()) {
        $output = '<div class="portfolio-items columns-' . esc_attr($args['columns']) . '">';
        while ($query->have_posts()) {
            $query->the_post();
            $output .= '<div class="portfolio-item">';
            ob_start(); // Start output buffering
            get_template_part('content', 'portfolio');
            $output .= ob_get_clean(); // End output buffering and append to $output
            $output .= '</div>';
        }
        wp_reset_postdata();
        $output .= '</div>';
    } else {
        $output = __('No portfolio items found.', 'textdomain');
    }

    return $output;
}

add_shortcode('portfolio', 'my_portfolio_shortcode');
